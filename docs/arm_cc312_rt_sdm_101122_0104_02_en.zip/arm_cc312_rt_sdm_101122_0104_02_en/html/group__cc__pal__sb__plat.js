var group__cc__pal__sb__plat =
[
    [ "cc_pal_sb_plat.h", "cc__pal__sb__plat_8h.html", null ],
    [ "CCAddr_t", "group__cc__pal__sb__plat.html#ga757efd625496717c850d43ec97e1f716", null ],
    [ "CCDmaAddr_t", "group__cc__pal__sb__plat.html#ga31d6a7bf19d14cccd94ae18cb448651a", null ]
];