var group__cc__ecpki__domains__defs =
[
    [ "cc_ecpki_domains_defs.h", "cc__ecpki__domains__defs_8h.html", null ],
    [ "getDomainFuncP", "group__cc__ecpki__domains__defs.html#gaf459290ce5a02a27406b64cc687a7680", null ]
];