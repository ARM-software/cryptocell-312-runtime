var cc__pka__hw__plat__defs_8h =
[
    [ "CC_PKA_WORD_SIZE_IN_BITS", "group__cc__pka__hw__plat__defs.html#gace13741a1d94b719f5314619bf613afc", null ],
    [ "CC_RSA_MAX_KEY_GENERATION_HW_SIZE_BITS", "group__cc__pka__hw__plat__defs.html#ga56f45ed22b8705c3b41a2f8b68ace001", null ],
    [ "CC_RSA_MAX_VALID_KEY_SIZE_VALUE_IN_BITS", "group__cc__pka__hw__plat__defs.html#ga270975d3a53b41bbba4f99425b57eba6", null ],
    [ "CC_RSA_MAX_VALID_KEY_SIZE_VALUE_IN_WORDS", "group__cc__pka__hw__plat__defs.html#ga3623c9136df2674e77f67afda9a9e6c5", null ],
    [ "CC_SRP_MAX_MODULUS_SIZE_IN_BITS", "group__cc__pka__hw__plat__defs.html#ga11ff1a584fe0cec1c0f6cc4de7ed4e9a", null ],
    [ "PKA_EXTRA_BITS", "group__cc__pka__hw__plat__defs.html#gac668bc56b2570b7cc13446e1e2564e2e", null ],
    [ "PKA_MAX_COUNT_OF_PHYS_MEM_REGS", "group__cc__pka__hw__plat__defs.html#ga22303769c4456400763ad739990b09a9", null ],
    [ "SB_CERT_RSA_KEY_SIZE_IN_BITS", "group__cc__pka__hw__plat__defs.html#gaf3995cc140cc118c4420d9124fc3c040", null ],
    [ "SB_CERT_RSA_KEY_SIZE_IN_BYTES", "group__cc__pka__hw__plat__defs.html#ga3b46e30169f43a8fffdc8ba79043fc1b", null ],
    [ "SB_CERT_RSA_KEY_SIZE_IN_WORDS", "group__cc__pka__hw__plat__defs.html#gaf6be587e2ca264800a9407a12847e589", null ]
];