var mbedtls__cc__ecdsa__edwards_8h =
[
    [ "mbedtls_ecdsa_genkey_edwards", "group__eddsa.html#ga1f4ee18b6a8b9221bd608a69a46f6349", null ],
    [ "mbedtls_ecdsa_public_key_read_edwards", "group__eddsa.html#gabfa06f9ea38e28e130b51d65be3bffa5", null ],
    [ "mbedtls_ecdsa_public_key_write_edwards", "group__eddsa.html#ga1ff2559825f060a7795dd9f8f60cc9f8", null ],
    [ "mbedtls_ecdsa_sign_edwards", "group__eddsa.html#ga93aad3aa63364394ee75ee1c6a0b0cca", null ],
    [ "mbedtls_ecdsa_verify_edwards", "group__eddsa.html#ga2df781f385b696f2ae8f27c35b3104d5", null ]
];