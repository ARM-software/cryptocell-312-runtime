var cc__cmpu_8h =
[
    [ "CMPU_WORKSPACE_MINIMUM_SIZE", "group__cc__cmpu.html#gac67327fbf7f4d0c230504c8e57c4ee90", null ],
    [ "PROD_UNIQUE_BUFF_SIZE", "group__cc__cmpu.html#ga7225caa6d11eac9f50d93aa0f2133c08", null ],
    [ "CCCmpuUniqueDataType_t", "group__cc__cmpu.html#ga4e633bf3ed24bba2c468dd5d81f4b788", [
      [ "CMPU_UNIQUE_IS_HBK0", "group__cc__cmpu.html#gga4e633bf3ed24bba2c468dd5d81f4b788a8ce95655f23f580669b7beb0e7464429", null ],
      [ "CMPU_UNIQUE_IS_USER_DATA", "group__cc__cmpu.html#gga4e633bf3ed24bba2c468dd5d81f4b788a31183385b8ecab42cd6d9dc1d0eac4bc", null ],
      [ "CMPU_UNIQUE_RESERVED", "group__cc__cmpu.html#gga4e633bf3ed24bba2c468dd5d81f4b788aa873aedebafcaf58b64998f95c7b8002", null ]
    ] ],
    [ "CCProd_Cmpu", "group__cc__cmpu.html#ga663c985fddc3a0ce154eb3544f532892", null ]
];