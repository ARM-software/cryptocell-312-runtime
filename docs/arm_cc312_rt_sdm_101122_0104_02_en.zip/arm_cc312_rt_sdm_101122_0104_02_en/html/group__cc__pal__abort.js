var group__cc__pal__abort =
[
    [ "cc_pal_abort.h", "cc__pal__abort_8h.html", null ],
    [ "CC_PalAbort", "group__cc__pal__abort.html#gae3cf88b87e2122c9561ee560fc8d01df", null ]
];