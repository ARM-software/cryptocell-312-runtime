var cc__address__defs_8h =
[
    [ "CCDmaAddr_t", "group__cc__general__defs.html#ga31d6a7bf19d14cccd94ae18cb448651a", null ],
    [ "CCSramAddr_t", "group__cc__general__defs.html#gaf859b880e99070f5e11c3f03d6d975f6", null ]
];