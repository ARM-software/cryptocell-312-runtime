var group__cc__sb__gen__defs =
[
    [ "secureboot_gen_defs.h", "secureboot__gen__defs_8h.html", null ],
    [ "CC_SB_MAX_SIZE_ADDITIONAL_DATA_BYTES", "group__cc__sb__gen__defs.html#gad1b435f7053853241d560dae18c3aa98", null ],
    [ "CCBsvFlashWriteFunc", "group__cc__sb__gen__defs.html#gab2b34317e3049c253ed1ac3c63538177", null ],
    [ "CCSbCertPubKeyHash_t", "group__cc__sb__gen__defs.html#ga401d6472dda1d5e52db656c18f75b3aa", null ],
    [ "CCSbCertSocId_t", "group__cc__sb__gen__defs.html#ga5889562f29450dadff26bd0e367e450f", null ],
    [ "CCSbFlashReadFunc", "group__cc__sb__gen__defs.html#ga8c5d5002934e8304d2ca6136a7789001", null ]
];