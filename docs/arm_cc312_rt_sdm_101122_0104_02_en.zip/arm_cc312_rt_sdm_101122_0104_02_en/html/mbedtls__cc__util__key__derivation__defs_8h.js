var mbedtls__cc__util__key__derivation__defs_8h =
[
    [ "CC_UTIL_FIX_DATA_MAX_SIZE_IN_BYTES", "group__cc__utils__key__defs.html#ga181c2a3f98b4bbdc54c1348b17c36de8", null ],
    [ "CC_UTIL_FIX_DATA_MIN_SIZE_IN_BYTES", "group__cc__utils__key__defs.html#ga5ec49aee7496a1f9109e2ce7e8c4dfa4", null ],
    [ "CC_UTIL_MAX_CONTEXT_LENGTH_IN_BYTES", "group__cc__utils__key__defs.html#ga8b3ec927cb22ada885c378b1f240253e", null ],
    [ "CC_UTIL_MAX_DERIVED_KEY_SIZE_IN_BYTES", "group__cc__utils__key__defs.html#ga19a9acb1dc26ea7bb9d421d2519784ba", null ],
    [ "CC_UTIL_MAX_KDF_SIZE_IN_BYTES", "group__cc__utils__key__defs.html#ga3e69b8d11a743b8e577b389211196000", null ],
    [ "CC_UTIL_MAX_LABEL_LENGTH_IN_BYTES", "group__cc__utils__key__defs.html#gac9ee18b126d480f0d9a6d8f46ae002d2", null ]
];