var group__ecdsa__module =
[
    [ "CryptoCell EDDSA Edwards curve APIs", "group__eddsa.html", "group__eddsa" ],
    [ "CryptoCell-312 hardware limitations for ECDSA", "group__cc__ecdsa__hw__limit.html", null ],
    [ "Typical usage of ECDSA in CryptoCell-312", "group__cc__ecdsa__typical.html", null ]
];