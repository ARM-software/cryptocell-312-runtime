var group__cc__dmpu =
[
    [ "cc_dmpu.h", "cc__dmpu_8h.html", null ],
    [ "CCDmpuHbkBuff_t", "union_c_c_dmpu_hbk_buff__t.html", [
      [ "hbk", "union_c_c_dmpu_hbk_buff__t.html#ae38243709ec81fdc3bb3a47ed756628f", null ],
      [ "hbk1", "union_c_c_dmpu_hbk_buff__t.html#a69c5ff775cdc58c4d3a5816ab4be9274", null ]
    ] ],
    [ "CCDmpuData_t", "struct_c_c_dmpu_data__t.html", [
      [ "hbkBuff", "struct_c_c_dmpu_data__t.html#afd03a28fef585c218e5edf131aa2b04f", null ],
      [ "hbkType", "struct_c_c_dmpu_data__t.html#a2df5b173391617846b4d25b02edb0e55", null ],
      [ "kce", "struct_c_c_dmpu_data__t.html#a8130f343683d5073d87f4da8cce6c7cc", null ],
      [ "kceDataType", "struct_c_c_dmpu_data__t.html#aa35e56db0c73da278400f011c1473cdd", null ],
      [ "kcp", "struct_c_c_dmpu_data__t.html#ad35d528ec11c41d13135a97f7e2432b2", null ],
      [ "kcpDataType", "struct_c_c_dmpu_data__t.html#adb735f7a4b17e85b7a042f8de9e3ab28", null ],
      [ "oemDcuDefaultLock", "struct_c_c_dmpu_data__t.html#a6111e6f129f344b63315836331e71a37", null ],
      [ "oemMinVersion", "struct_c_c_dmpu_data__t.html#a2a39ef30866fd0cac6e733967b3780d9", null ]
    ] ],
    [ "DMPU_HBK1_SIZE_IN_WORDS", "group__cc__dmpu.html#ga1df890fd4cd2dde8e13f4ae4df2a0bf9", null ],
    [ "DMPU_HBK_SIZE_IN_WORDS", "group__cc__dmpu.html#ga7f7402acae56abf0a5a5860e16dcfaf8", null ],
    [ "DMPU_WORKSPACE_MINIMUM_SIZE", "group__cc__dmpu.html#ga936e093580f1e62fe7ae1fdc6e6a569b", null ],
    [ "CCDmpuHBKType_t", "group__cc__dmpu.html#ga8427cdb4973afbf5dc62fce810bca7ee", [
      [ "DMPU_HBK_TYPE_HBK1", "group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eeaa2d459ebfffe55c024c75c5c3b0d07cb", null ],
      [ "DMPU_HBK_TYPE_HBK", "group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eea22621b9fa3b077f0d2df35235839a103", null ],
      [ "DMPU_HBK_TYPE_RESERVED", "group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eea5e4bf1fe2a73d9794192d93fba2ab77c", null ]
    ] ],
    [ "CCProd_Dmpu", "group__cc__dmpu.html#ga93c952fedf1f18bd291f962cccfa5e15", null ]
];