var group__rng__module =
[
    [ "CryptoCell random-number generation APIs.", "group__cc__rnd.html", "group__cc__rnd" ]
];