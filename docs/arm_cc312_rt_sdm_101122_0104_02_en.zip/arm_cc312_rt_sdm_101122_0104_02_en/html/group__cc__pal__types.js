var group__cc__pal__types =
[
    [ "cc_pal_types.h", "cc__pal__types_8h.html", null ],
    [ "CALC_32BIT_WORDS_FROM_64BIT_DWORD", "group__cc__pal__types.html#gac77150bf4b86d382b7ce563fab73bd7a", null ],
    [ "CALC_32BIT_WORDS_FROM_BYTES", "group__cc__pal__types.html#ga4b8278cbd6cca5cf9cb6e147e58fe551", null ],
    [ "CALC_FULL_32BIT_WORDS", "group__cc__pal__types.html#gac8b1db80015339ef136edc3c4ac007dd", null ],
    [ "CALC_FULL_BYTES", "group__cc__pal__types.html#ga3f3675f633501e0d20f11eac433849ac", null ],
    [ "CC_1K_SIZE_IN_BYTES", "group__cc__pal__types.html#ga0f580de989dbbc4a1cd5a2f74f04c222", null ],
    [ "CC_32BIT_WORD_IN_64BIT_DWORD", "group__cc__pal__types.html#ga58f333ec024ff6f9afceff88c7fd7fec", null ],
    [ "CC_32BIT_WORD_SIZE", "group__cc__pal__types.html#ga8770c948c3fde3460ed209a29f477f41", null ],
    [ "CC_BITS_IN_32BIT_WORD", "group__cc__pal__types.html#gac0d9f5c4b00d3df68f09ab4b2835cdda", null ],
    [ "CC_BITS_IN_BYTE", "group__cc__pal__types.html#ga22203268cd80a22ab491ac05abf2ae75", null ],
    [ "CC_FAIL", "group__cc__pal__types.html#gab800e20dca424a24df2e3ec82cedfe43", null ],
    [ "CC_MAX", "group__cc__pal__types.html#ga4b785d44bac1d8547f9d91ce5d4f0c11", null ],
    [ "CC_MAX_UINT32_VAL", "group__cc__pal__types.html#ga4d22c6758e7a4edebc6a176e9202004b", null ],
    [ "CC_MIN", "group__cc__pal__types.html#ga5faeb17655e1ac03a0addfc7d95abdde", null ],
    [ "CC_OK", "group__cc__pal__types.html#ga1c488b11964d5f296c0e22e142511f13", null ],
    [ "CC_SUCCESS", "group__cc__pal__types.html#ga63518241002936d117d6f9306b51be4f", null ],
    [ "CC_UNUSED_PARAM", "group__cc__pal__types.html#gacd13ab26f93f7797ae09307b478ba1d6", null ],
    [ "ROUNDUP_BITS_TO_32BIT_WORD", "group__cc__pal__types.html#gacbcea5688bb56392399e922929a34416", null ],
    [ "ROUNDUP_BITS_TO_BYTES", "group__cc__pal__types.html#ga79ea248a3e90a8c63cc2899b500745a4", null ],
    [ "ROUNDUP_BYTES_TO_32BIT_WORD", "group__cc__pal__types.html#ga68ed0e4612e0b3f105cd98fec6d4096b", null ],
    [ "CCBool", "group__cc__pal__types.html#ga7323bc031012d4ecc054f5ac4b9a1e76", [
      [ "CC_FALSE", "group__cc__pal__types.html#gga7323bc031012d4ecc054f5ac4b9a1e76a6f15eba2bf45deaeaf625e9cad6492fa", null ],
      [ "CC_TRUE", "group__cc__pal__types.html#gga7323bc031012d4ecc054f5ac4b9a1e76a286c1b1735c565b56145da9bd3e1f9fe", null ]
    ] ]
];