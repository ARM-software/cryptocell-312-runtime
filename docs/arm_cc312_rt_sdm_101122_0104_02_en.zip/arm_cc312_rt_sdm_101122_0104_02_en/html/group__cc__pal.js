var group__cc__pal =
[
    [ "CryptoCell PAL APB-C APIs", "group__cc__pal__apbc.html", "group__cc__pal__apbc" ],
    [ "CryptoCell PAL TRNG APIs", "group__cc__pal__trng.html", "group__cc__pal__trng" ],
    [ "CryptoCell PAL abort operations", "group__cc__pal__abort.html", "group__cc__pal__abort" ],
    [ "CryptoCell PAL definitions for Boot Services", "group__cc__pal__sb__plat.html", "group__cc__pal__sb__plat" ],
    [ "CryptoCell PAL entry or exit point APIs", "group__cc__pal__init.html", "group__cc__pal__init" ],
    [ "CryptoCell PAL logging APIs and definitions", "group__cc__pal__log.html", "group__cc__pal__log" ],
    [ "CryptoCell PAL memory operations", "group__cc__pal__mem.html", "group__cc__pal__mem" ],
    [ "CryptoCell PAL mutex APIs", "group__cc__pal__mutex.html", "group__cc__pal__mutex" ],
    [ "CryptoCell PAL platform-dependent compiler-related definitions", "group__cc__pal__compiler.html", "group__cc__pal__compiler" ],
    [ "CryptoCell PAL platform-dependent definitions and types", "group__cc__pal__types.html", "group__cc__pal__types" ],
    [ "CryptoCell PAL power-management APIs", "group__cc__pal__pm.html", "group__cc__pal__pm" ],
    [ "Specific errors of the CryptoCell PAL APIs", "group__cc__pal__error.html", "group__cc__pal__error" ]
];