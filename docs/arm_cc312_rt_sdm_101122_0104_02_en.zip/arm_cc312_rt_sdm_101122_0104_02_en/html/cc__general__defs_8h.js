var cc__general__defs_8h =
[
    [ "CC_AES_KDR_MAX_SIZE_BYTES", "group__cc__general__defs.html#gad8d4d5f51af423b93391a4d06cbb74de", null ],
    [ "CC_AES_KDR_MAX_SIZE_WORDS", "group__cc__general__defs.html#gafac397175cf836ecfb760a252b5c064b", null ],
    [ "CC_HASH_NAME_MAX_SIZE", "group__cc__general__defs.html#ga2f638e8cb5c48fe0b47f0e08e4a7c993", null ],
    [ "CC_LCS_CHIP_MANUFACTURE_LCS", "group__cc__general__defs.html#ga7b29e7cf8615fc5fbb88c1be7793f58c", null ],
    [ "CC_LCS_SECURE_LCS", "group__cc__general__defs.html#ga0442765153525854fe0a36c83c6a1bb5", null ],
    [ "HashAlgMode2mbedtlsString", "group__cc__general__defs.html#ga3e0e0e7173f59efffb6d8488d1f76678", null ],
    [ "HmacHashInfo_t", "group__cc__general__defs.html#gaa4bb541ea88565b34040feec978d4ac7", null ],
    [ "HmacSupportedHashModes_t", "group__cc__general__defs.html#gad6d0388f6b7c173a2bd1d1155e619a15", null ]
];