var group__dhm__module =
[
    [ "CryptoCell-312 hardware limitations for DHM", "group__cc__dhm__hw__limit.html", null ],
    [ "Typical usage of DHM in CryptoCell-312", "group__cc__dhm__typical.html", null ]
];