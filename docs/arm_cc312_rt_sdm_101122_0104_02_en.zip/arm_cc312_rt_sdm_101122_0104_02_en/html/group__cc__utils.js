var group__cc__utils =
[
    [ "CryptoCell runtime-library asset-provisioning APIs", "group__cc__util__asset__prov.html", "group__cc__util__asset__prov" ],
    [ "CryptoCell utility APIs general definitions", "group__cc__utils__defs.html", "group__cc__utils__defs" ],
    [ "CryptoCell utility key-derivation APIs", "group__cc__utils__key__derivation.html", "group__cc__utils__key__derivation" ],
    [ "Specific errors of the CryptoCell utility module APIs", "group__cc__utils__errors.html", "group__cc__utils__errors" ]
];