var cc__util__error_8h =
[
    [ "CC_UTIL_BAD_ADDR_ERROR", "group__cc__utils__errors.html#gabfbfb827d68130bf7fc37d48f21add63", null ],
    [ "CC_UTIL_DATA_IN_POINTER_INVALID_ERROR", "group__cc__utils__errors.html#ga42510be6e3e53372ba506d1602ce726c", null ],
    [ "CC_UTIL_DATA_IN_SIZE_INVALID_ERROR", "group__cc__utils__errors.html#gaa828bb8f0c5ef7db7a1f0dfe60d89637", null ],
    [ "CC_UTIL_DATA_OUT_POINTER_INVALID_ERROR", "group__cc__utils__errors.html#gacb798ec1b515620212222e94fe275eed", null ],
    [ "CC_UTIL_DATA_OUT_SIZE_INVALID_ERROR", "group__cc__utils__errors.html#ga8b4127ce7bc8ac6d2b5157fe65738312", null ],
    [ "CC_UTIL_EK_DOMAIN_INVALID_ERROR", "group__cc__utils__errors.html#gab030975efb6d47e82aa401924ea7f1b9", null ],
    [ "CC_UTIL_FATAL_ERROR", "group__cc__utils__errors.html#ga29a47cf1b1ef8ae0b525666870884cc5", null ],
    [ "CC_UTIL_ILLEGAL_LCS_FOR_OPERATION_ERR", "group__cc__utils__errors.html#ga6b627689734e82d71a6ac4abefca0d39", null ],
    [ "CC_UTIL_ILLEGAL_PARAMS_ERROR", "group__cc__utils__errors.html#ga30126768547d78ad9ccf0dcf45c525e7", null ],
    [ "CC_UTIL_INVALID_HASH_MODE", "group__cc__utils__errors.html#ga1206c9609175220e7ff669825b2f3fa0", null ],
    [ "CC_UTIL_INVALID_KEY_TYPE", "group__cc__utils__errors.html#ga3132c1d7185636ce7f15759f5d6e0dd7", null ],
    [ "CC_UTIL_INVALID_PRF_TYPE", "group__cc__utils__errors.html#ga95228c751f363e2da265b5f297ed9f26", null ],
    [ "CC_UTIL_INVALID_USER_KEY_SIZE", "group__cc__utils__errors.html#ga2de64ca5e9eb1fa79eb30fa060deb443", null ],
    [ "CC_UTIL_KDR_INVALID_ERROR", "group__cc__utils__errors.html#ga6c9c3617104e7b86be6671487f74a9c3", null ],
    [ "CC_UTIL_KEY_UNUSABLE_ERROR", "group__cc__utils__errors.html#gad8008bcdb8d4eda32402b60fc76645d0", null ],
    [ "CC_UTIL_LCS_INVALID_ERROR", "group__cc__utils__errors.html#gaefb6f6821d59415d5f7550c4f04e5ac2", null ],
    [ "CC_UTIL_MODULE_ERROR_BASE", "group__cc__utils__errors.html#gac92e4526578361998dbf7c2a5c129804", null ],
    [ "CC_UTIL_OK", "group__cc__utils__errors.html#ga7308db944b0f0b8f926313e9810b5f13", null ],
    [ "CC_UTIL_SESSION_KEY_ERROR", "group__cc__utils__errors.html#ga31ecccea98c6943929595f28748cf423", null ],
    [ "CC_UTIL_UNSUPPORTED_HASH_MODE", "group__cc__utils__errors.html#gae5a5f34be4ca496805c561ae4c9dcaef", null ]
];