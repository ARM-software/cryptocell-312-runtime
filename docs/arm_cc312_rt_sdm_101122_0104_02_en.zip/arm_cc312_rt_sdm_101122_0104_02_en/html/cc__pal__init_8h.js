var cc__pal__init_8h =
[
    [ "CC_PalInit", "group__cc__pal__init.html#ga038a39766b736c6a0d8f0d2d82af232b", null ],
    [ "CC_PalTerminate", "group__cc__pal__init.html#ga2ab70dc6a94091d3391995b8f9f67c50", null ]
];