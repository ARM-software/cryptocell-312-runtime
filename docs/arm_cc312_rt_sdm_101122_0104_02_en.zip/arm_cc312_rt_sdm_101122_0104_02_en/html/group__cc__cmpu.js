var group__cc__cmpu =
[
    [ "cc_cmpu.h", "cc__cmpu_8h.html", null ],
    [ "CCCmpuUniqueBuff_t", "union_c_c_cmpu_unique_buff__t.html", [
      [ "hbk0", "union_c_c_cmpu_unique_buff__t.html#afefb2066ffee9dbbb5d509df91c502c9", null ],
      [ "userData", "union_c_c_cmpu_unique_buff__t.html#af21a4f596d133bd5e86320f45aeda018", null ]
    ] ],
    [ "CCCmpuData_t", "struct_c_c_cmpu_data__t.html", [
      [ "icvConfigWord", "struct_c_c_cmpu_data__t.html#a12b6be6b7e61b9aae8d765def0dee844", null ],
      [ "icvDcuDefaultLock", "struct_c_c_cmpu_data__t.html#af715bdb52953070874d346dde5f5a61a", null ],
      [ "icvMinVersion", "struct_c_c_cmpu_data__t.html#a889e1d9ae02d0bb2fdc0f12726c55111", null ],
      [ "kceicv", "struct_c_c_cmpu_data__t.html#a00a2ad725ad8583ec414adc6310b4a39", null ],
      [ "kceicvDataType", "struct_c_c_cmpu_data__t.html#a887b5e796e55929f42c36b1e9ca8fab2", null ],
      [ "kpicv", "struct_c_c_cmpu_data__t.html#a2ac24ed8d7c271cef0c635509d98b8c8", null ],
      [ "kpicvDataType", "struct_c_c_cmpu_data__t.html#aa26802bb6a5fba5bddd1eab168b0f9f9", null ],
      [ "uniqueBuff", "struct_c_c_cmpu_data__t.html#ade641d7a8a947f9a9a241cd2369a7f1a", null ],
      [ "uniqueDataType", "struct_c_c_cmpu_data__t.html#a3e2977f3265904d474228d5193655524", null ]
    ] ],
    [ "CMPU_WORKSPACE_MINIMUM_SIZE", "group__cc__cmpu.html#gac67327fbf7f4d0c230504c8e57c4ee90", null ],
    [ "PROD_UNIQUE_BUFF_SIZE", "group__cc__cmpu.html#ga7225caa6d11eac9f50d93aa0f2133c08", null ],
    [ "CCCmpuUniqueDataType_t", "group__cc__cmpu.html#ga4e633bf3ed24bba2c468dd5d81f4b788", [
      [ "CMPU_UNIQUE_IS_HBK0", "group__cc__cmpu.html#gga4e633bf3ed24bba2c468dd5d81f4b788a8ce95655f23f580669b7beb0e7464429", null ],
      [ "CMPU_UNIQUE_IS_USER_DATA", "group__cc__cmpu.html#gga4e633bf3ed24bba2c468dd5d81f4b788a31183385b8ecab42cd6d9dc1d0eac4bc", null ],
      [ "CMPU_UNIQUE_RESERVED", "group__cc__cmpu.html#gga4e633bf3ed24bba2c468dd5d81f4b788aa873aedebafcaf58b64998f95c7b8002", null ]
    ] ],
    [ "CCProd_Cmpu", "group__cc__cmpu.html#ga663c985fddc3a0ce154eb3544f532892", null ]
];