var group__ext__dma =
[
    [ "CryptoCell AES external DMA APIs", "group__aes__ext__dma.html", "group__aes__ext__dma" ],
    [ "CryptoCell ChaCha external DMA APIs", "group__chacha__ext__dma.html", "group__chacha__ext__dma" ],
    [ "CryptoCell hash external DMA APIs", "group__hash__ext__dma.html", "group__hash__ext__dma" ],
    [ "Specific errors of the CryptoCell external DMA APIs", "group__ext__dma__errors.html", "group__ext__dma__errors" ]
];