var group__ext__dma__errors =
[
    [ "mbedtls_ext_dma_error.h", "mbedtls__ext__dma__error_8h.html", null ],
    [ "EXT_DMA_AES_DECRYPTION_NOT_ALLOWED_ON_THIS_MODE", "group__ext__dma__errors.html#ga6f0a9a0911867ea91fc1917577d7789d", null ],
    [ "EXT_DMA_AES_ILLEGAL_KEY_SIZE_ERROR", "group__ext__dma__errors.html#ga7aede2c9e4b21d3dfca8be355fd8a58a", null ],
    [ "EXT_DMA_AES_ILLEGAL_OPERATION_MODE_ERROR", "group__ext__dma__errors.html#ga8d8b9f2e209f3c3b601f69303d161a50", null ],
    [ "EXT_DMA_AES_INVALID_ENCRYPT_MODE_ERROR", "group__ext__dma__errors.html#gad3acde85835cfebe9b2b290190004558", null ],
    [ "EXT_DMA_AES_INVALID_IV_OR_TWEAK_PTR_ERROR", "group__ext__dma__errors.html#gabe3391967de1ca49bc7bcaec0c68fde3", null ],
    [ "EXT_DMA_CHACHA_ILLEGAL_INPUT_SIZE_ERROR", "group__ext__dma__errors.html#ga7a7b5faf824186cfb8539d0088098c11", null ],
    [ "EXT_DMA_CHACHA_ILLEGAL_KEY_SIZE_ERROR", "group__ext__dma__errors.html#ga3edad12c23547fb5a03d7547d8f7b51e", null ],
    [ "EXT_DMA_CHACHA_INVALID_ENCRYPT_MODE_ERROR", "group__ext__dma__errors.html#ga83f42ee3c05a650bd2f4ee37a7318fbe", null ],
    [ "EXT_DMA_CHACHA_INVALID_KEY_POINTER_ERROR", "group__ext__dma__errors.html#ga4338ffa00d29a641661d3f7aaf5bf0f7", null ],
    [ "EXT_DMA_CHACHA_INVALID_NONCE_ERROR", "group__ext__dma__errors.html#gaca997054762f144887835d8a9e470c91", null ],
    [ "EXT_DMA_CHACHA_INVALID_NONCE_PTR_ERROR", "group__ext__dma__errors.html#gabcdabf89064e03b7b150e69feb564c31", null ],
    [ "EXT_DMA_HASH_ILLEGAL_OPERATION_MODE_ERROR", "group__ext__dma__errors.html#ga0fcdc30be388c42866c298c7198f3621", null ],
    [ "EXT_DMA_HASH_ILLEGAL_PARAMS_ERROR", "group__ext__dma__errors.html#ga3fff5c2451e2723ae53f4ef38b842702", null ],
    [ "EXT_DMA_HASH_INVALID_RESULT_BUFFER_POINTER_ERROR", "group__ext__dma__errors.html#ga9e0f03dca3efb613d5a54dd2cd4e7dca", null ],
    [ "EXT_DMA_ILLEGAL_INPUT_SIZE_ERROR", "group__ext__dma__errors.html#ga2d711c2b35b2f29aabd8edce9e7ec9cc", null ]
];