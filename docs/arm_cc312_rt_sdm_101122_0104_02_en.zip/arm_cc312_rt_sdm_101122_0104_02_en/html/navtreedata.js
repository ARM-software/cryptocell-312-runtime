/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Arm® CryptoCell™-312 Runtime Software Developers Manual", "index.html", [
    [ "Arm® CryptoCell™-312 Runtime software API overview", "index.html", [
      [ "Confidentiality status", "index.html#conf_status", null ],
      [ "Proprietary notice", "index.html#proprietary_notice", null ],
      [ "Additional reading", "index.html#add_read", null ],
      [ "Glossary", "index.html#glossary", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"aes_8h.html",
"ctr__drbg_8h.html#a1ea42b9eb6f6b33c82359f4c0a57ca43",
"globals_a.html",
"group__cc__ecpki__types.html#gga44f384a43477b801bcb31307516efd39a3d8f655554ae66b5dcfc64f8b38f2548",
"group__cc__hash__defs.html#ga8ca3771d14e92e74f5ed2806a9604e0d",
"group__cc__pal__error.html#ga1ab7d03407d44dce8beb9fbcb8b90758",
"group__cc__rnd.html#gga552b9e6baa74b27633d0b03c0f4e0641aa56ebb28fd212465c40cc17109c50ba1",
"group__cc__utils__key__defs.html#ga181c2a3f98b4bbdc54c1348b17c36de8",
"poly1305_8h.html#a77119b4e0b97c7566c87fa2769f34ccc",
"struct_ecdsa_verify_context__t.html#aa052d7d65f0a49c46eaf4f47dc7790f2"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';