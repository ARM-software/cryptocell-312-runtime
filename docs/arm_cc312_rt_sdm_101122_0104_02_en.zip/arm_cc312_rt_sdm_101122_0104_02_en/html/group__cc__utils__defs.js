var group__cc__utils__defs =
[
    [ "mbedtls_cc_util_defs.h", "mbedtls__cc__util__defs_8h.html", null ],
    [ "mbedtls_util_keydata", "structmbedtls__util__keydata.html", [
      [ "keySize", "structmbedtls__util__keydata.html#aa01d95995767d8ac447d6ddc0ed34d67", null ],
      [ "pKey", "structmbedtls__util__keydata.html#a86bc31d2db2de334a6306fef97b78e00", null ]
    ] ],
    [ "CC_UTIL_AES_128BIT_SIZE", "group__cc__utils__defs.html#gaf0bea333e31b0d956a709bce629f8820", null ],
    [ "CC_UTIL_AES_192BIT_SIZE", "group__cc__utils__defs.html#gab74c5d4a8e81b2e461509d98641794d1", null ],
    [ "CC_UTIL_AES_256BIT_SIZE", "group__cc__utils__defs.html#gaabe35eaa40d07134cc0db4dbac7d583d", null ],
    [ "CC_UTIL_AES_CMAC_RESULT_SIZE_IN_BYTES", "group__cc__utils__defs.html#gafbdd20615ed5d4b250d14717702778bc", null ],
    [ "CC_UTIL_AES_CMAC_RESULT_SIZE_IN_WORDS", "group__cc__utils__defs.html#gac7a5bba6797a5c015b18e798911dcf47", null ],
    [ "CC_UTIL_CMAC_DERV_MAX_DATA_IN_SIZE", "group__cc__utils__defs.html#ga967ed91974630cb5bd4a34de9023f332", null ],
    [ "CC_UTIL_CMAC_DERV_MIN_DATA_IN_SIZE", "group__cc__utils__defs.html#gafa652f44fb55abdec0709a4cd1bea2c0", null ],
    [ "CCUtilError_t", "group__cc__utils__defs.html#ga7c059d17ee3347283a7e2793b60944d1", null ],
    [ "mbedtls_util_keydata", "group__cc__utils__defs.html#ga6eaeb774cf28d6e3bee18e693274b727", null ]
];