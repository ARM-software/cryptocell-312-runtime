var bootimagesverifier__def_8h =
[
    [ "CC_SB_MAX_CERT_SIZE_IN_BYTES", "group__cc__sb__image__verifier.html#gabce69f583714310f2312e87942c39630", null ],
    [ "CC_SB_MAX_CERT_SIZE_IN_WORDS", "group__cc__sb__image__verifier.html#gaffb7eb6cb1088891a977348946f23812", null ],
    [ "CC_SB_MAX_NUM_OF_IMAGES", "group__cc__sb__image__verifier.html#ga5be6c59bfa60142d917d0760d5745fcd", null ],
    [ "CC_SB_MIN_DBG_WORKSPACE_SIZE_IN_BYTES", "group__cc__sb__image__verifier.html#ga67a4a29e85684334817bb01d4463f543", null ],
    [ "CC_SB_MIN_WORKSPACE_SIZE_IN_BYTES", "group__cc__sb__image__verifier.html#ga1e3513f84f083a232434650b90b65380", null ]
];