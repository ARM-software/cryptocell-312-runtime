var cc__lib_8h =
[
    [ "DX_VERSION_PRODUCT_BIT_SHIFT", "group__cc__lib.html#gab34a4472043f3e154463b52c6d8e52a6", null ],
    [ "DX_VERSION_PRODUCT_BIT_SIZE", "group__cc__lib.html#ga5114e1b78206a67e9a6fada4133b5fc1", null ],
    [ "CClibRetCode_t", "group__cc__lib.html#ga8b1459df11e9fb00a2c181eaf53384cb", [
      [ "CC_LIB_RET_OK", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cba2d5bfe7f270520b4b4c1cbcf23bbc5ba", null ],
      [ "CC_LIB_RET_EINVAL_CTX_PTR", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cbad961a5824b319a2bd1c2ae9396c27ddc", null ],
      [ "CC_LIB_RET_EINVAL_WORK_BUF_PTR", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cbaec1df1b5ca9ed539729fb3e4e9fa21d2", null ],
      [ "CC_LIB_RET_HAL", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cbab80fd6aff438dc3b305b1768971d84ce", null ],
      [ "CC_LIB_RET_PAL", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cba9417eb8dd5da70a46d2da67451a6287f", null ],
      [ "CC_LIB_RET_RND_INST_ERR", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cba78e62c067c0ed1d43a902ac72841b257", null ],
      [ "CC_LIB_RET_EINVAL_PIDR", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cba8bce30fb655d87bf5a704845ffdc92fe", null ],
      [ "CC_LIB_RET_EINVAL_CIDR", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cba22d298da2ebe5fda5ac493cac8bfa8b6", null ],
      [ "CC_LIB_AO_WRITE_FAILED_ERR", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cbafb74c349810964e5de907edc1f872920", null ],
      [ "CC_LIB_RESERVE32B", "group__cc__lib.html#gga8b1459df11e9fb00a2c181eaf53384cba0d97f41b34bea24d49a8e780ee38214a", null ]
    ] ],
    [ "CC_LibFini", "group__cc__lib.html#gaaf9a35ace95902fbc2a49f208b9a6188", null ],
    [ "CC_LibInit", "group__cc__lib.html#ga994c0d0946dc03bf0347016cbfb875f0", null ]
];