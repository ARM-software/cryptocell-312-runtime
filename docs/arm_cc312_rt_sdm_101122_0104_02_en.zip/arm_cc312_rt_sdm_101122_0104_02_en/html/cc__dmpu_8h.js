var cc__dmpu_8h =
[
    [ "DMPU_HBK1_SIZE_IN_WORDS", "group__cc__dmpu.html#ga1df890fd4cd2dde8e13f4ae4df2a0bf9", null ],
    [ "DMPU_HBK_SIZE_IN_WORDS", "group__cc__dmpu.html#ga7f7402acae56abf0a5a5860e16dcfaf8", null ],
    [ "DMPU_WORKSPACE_MINIMUM_SIZE", "group__cc__dmpu.html#ga936e093580f1e62fe7ae1fdc6e6a569b", null ],
    [ "CCDmpuHBKType_t", "group__cc__dmpu.html#ga8427cdb4973afbf5dc62fce810bca7ee", [
      [ "DMPU_HBK_TYPE_HBK1", "group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eeaa2d459ebfffe55c024c75c5c3b0d07cb", null ],
      [ "DMPU_HBK_TYPE_HBK", "group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eea22621b9fa3b077f0d2df35235839a103", null ],
      [ "DMPU_HBK_TYPE_RESERVED", "group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eea5e4bf1fe2a73d9794192d93fba2ab77c", null ]
    ] ],
    [ "CCProd_Dmpu", "group__cc__dmpu.html#ga93c952fedf1f18bd291f962cccfa5e15", null ]
];