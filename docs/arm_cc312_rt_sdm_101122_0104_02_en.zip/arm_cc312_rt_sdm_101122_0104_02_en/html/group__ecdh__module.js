var group__ecdh__module =
[
    [ "CryptoCell ECDH Edwards curve APIs", "group__ecdh__edwards.html", null ],
    [ "CryptoCell-312 hardware limitations for ECDH", "group__cc__ecdh__hw__limit.html", null ],
    [ "Typical usage of ECDH in CryptoCell-312", "group__cc__ecdh__typical.html", null ]
];