var group__cc__sram__map =
[
    [ "cc_sram_map.h", "cc__sram__map_8h.html", null ],
    [ "CC_PKA_SRAM_SIZE_IN_KBYTES", "group__cc__sram__map.html#ga994d4e8d8c6a98eca2261013d06a3821", null ],
    [ "CC_SRAM_MAX_SIZE", "group__cc__sram__map.html#gaa26a2228af5391af2b0898c889a44c18", null ],
    [ "CC_SRAM_PKA_BASE_ADDRESS", "group__cc__sram__map.html#gab0db6123208f96fd1631708188719a6d", null ],
    [ "CC_SRAM_RND_HW_DMA_ADDRESS", "group__cc__sram__map.html#ga1d9aae525f249280366b15c8c033f773", null ],
    [ "CC_SRAM_RND_MAX_SIZE", "group__cc__sram__map.html#ga6408076de13f4502f349197d67a71bef", null ]
];