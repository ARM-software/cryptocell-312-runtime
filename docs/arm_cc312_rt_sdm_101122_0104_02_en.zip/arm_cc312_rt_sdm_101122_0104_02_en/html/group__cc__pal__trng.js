var group__cc__pal__trng =
[
    [ "cc_pal_trng.h", "cc__pal__trng_8h.html", null ],
    [ "CC_PalTrngParams_t", "struct_c_c___pal_trng_params__t.html", [
      [ "SubSamplingRatio1", "struct_c_c___pal_trng_params__t.html#a1bddb762eec955c73c0a2a8b47b6dbe4", null ],
      [ "SubSamplingRatio2", "struct_c_c___pal_trng_params__t.html#aaf92104b9439ee559a04c9470b368005", null ],
      [ "SubSamplingRatio3", "struct_c_c___pal_trng_params__t.html#aa42f5daa1917f370557f1055fd4dc095", null ],
      [ "SubSamplingRatio4", "struct_c_c___pal_trng_params__t.html#a6bf7030b53a920bb41637a094100cc00", null ]
    ] ],
    [ "CC_PalTrngParams_t", "group__cc__pal__trng.html#ga221a30b27e78c68516be9fe29911cac5", null ],
    [ "CC_PalTrngParamGet", "group__cc__pal__trng.html#gac824bdd34329c776d9fb0619cd5beeb8", null ]
];