var group__cc__aes__defs__proj =
[
    [ "cc_aes_defs_proj.h", "cc__aes__defs__proj_8h.html", null ],
    [ "CC_AES_KEY_MAX_SIZE_IN_BYTES", "group__cc__aes__defs__proj.html#gafb64dc5cd5c5315e91d852ac4ad01df5", null ],
    [ "CC_AES_KEY_MAX_SIZE_IN_WORDS", "group__cc__aes__defs__proj.html#gac1e99ed13a5dca1134454ed291b1cb26", null ],
    [ "CC_AES_USER_CTX_SIZE_IN_WORDS", "group__cc__aes__defs__proj.html#ga2fc4eadbfe1005fa323f5cd2d10d243d", null ]
];