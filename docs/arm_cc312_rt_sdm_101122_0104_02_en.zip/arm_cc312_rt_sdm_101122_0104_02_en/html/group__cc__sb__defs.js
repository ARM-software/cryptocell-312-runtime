var group__cc__sb__defs =
[
    [ "CryptoCell Secure Boot and Secure Debug definitions and structures", "group__cc__sb__gen__defs.html", "group__cc__sb__gen__defs" ],
    [ "secureboot_defs.h", "secureboot__defs_8h.html", null ],
    [ "CCSbCertInfo_t", "struct_c_c_sb_cert_info__t.html", [
      [ "activeMinSwVersionVal", "struct_c_c_sb_cert_info__t.html#a4845d310370c1bbaf493ef4a08723ff2", null ],
      [ "initDataFlag", "struct_c_c_sb_cert_info__t.html#a05256985db0ab141ed297957a14b685e", null ],
      [ "keyIndex", "struct_c_c_sb_cert_info__t.html#aced0078f9874c1243dd8f3522eef8897", null ],
      [ "otpVersion", "struct_c_c_sb_cert_info__t.html#a046ee76e68713776768fd040e337b03d", null ],
      [ "pubKeyHash", "struct_c_c_sb_cert_info__t.html#af595bb54c2674a7c94b8014106ce2aa9", null ]
    ] ],
    [ "CC_SW_COMP_NO_MEM_LOAD_INDICATION", "group__cc__sb__defs.html#ga810597792567ff82c52fe7659d2007f3", null ],
    [ "SW_REC_NONE_SIGNED_DATA_SIZE_IN_BYTES", "group__cc__sb__defs.html#ga1f02246096126ef3a615778dbd336555", null ],
    [ "SW_REC_NONE_SIGNED_DATA_SIZE_IN_WORDS", "group__cc__sb__defs.html#ga3d703edcf43b6536bcc77bc59b3392ca", null ],
    [ "SW_REC_SIGNED_DATA_SIZE_IN_BYTES", "group__cc__sb__defs.html#ga200b251d5ffb7168170988e9b11c05d0", null ]
];