var group__cc__pal__error =
[
    [ "cc_pal_error.h", "cc__pal__error_8h.html", null ],
    [ "CC_PAL_BASE_ERROR", "group__cc__pal__error.html#ga3df271126812b6501ca8d503a885e124", null ],
    [ "CC_PAL_ILLEGAL_ADDRESS", "group__cc__pal__error.html#ga57e06363c0ceef707493d14daa486576", null ],
    [ "CC_PAL_MEM_BUF1_GREATER", "group__cc__pal__error.html#ga8a8ef88e56efa2f1a450b2a08468c074", null ],
    [ "CC_PAL_MEM_BUF2_GREATER", "group__cc__pal__error.html#ga7d1834ccbc2e2f9697ef610ff767747b", null ],
    [ "CC_PAL_SEM_CREATE_FAILED", "group__cc__pal__error.html#gaf95d19d468eba90e8b20576512a9e67e", null ],
    [ "CC_PAL_SEM_DELETE_FAILED", "group__cc__pal__error.html#ga471787c0c866c005937b1f3083b8b930", null ],
    [ "CC_PAL_SEM_RELEASE_FAILED", "group__cc__pal__error.html#ga7733929ce0d272b4dd6187f0442ee7d0", null ],
    [ "CC_PAL_SEM_WAIT_FAILED", "group__cc__pal__error.html#ga1ab7d03407d44dce8beb9fbcb8b90758", null ],
    [ "CC_PAL_SEM_WAIT_TIMEOUT", "group__cc__pal__error.html#gadc64c223f1d0b83013d0b825972790bd", null ]
];