var globals_func =
[
    [ "c", "globals_func.html", null ],
    [ "m", "globals_func_m.html", null ]
];