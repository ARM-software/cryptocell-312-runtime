var group__cc__aes =
[
    [ "CryptoCell AES-CCM star APIs", "group__cc__aesccm__star.html", "group__cc__aesccm__star" ],
    [ "CryptoCell-312 hardware limitations for AES", "group__cc__aes__hw__limit.html", null ],
    [ "Definitions of CryptoCell AES APIs", "group__cc__aes__defs.html", "group__cc__aes__defs" ],
    [ "Typical usage of AES in CryptoCell-312", "group__cc__aes__typical.html", null ]
];