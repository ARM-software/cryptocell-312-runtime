var group__chacha__ext__dma =
[
    [ "mbedtls_chacha_ext_dma.h", "mbedtls__chacha__ext__dma_8h.html", null ],
    [ "mbedtls_chacha_ext_dma_finish", "group__chacha__ext__dma.html#ga4c8044496baff134d23d5c3f3475ef05", null ],
    [ "mbedtls_ext_dma_chacha_init", "group__chacha__ext__dma.html#ga8c7ffdfb5eeadde97ef56156ac4f213d", null ]
];