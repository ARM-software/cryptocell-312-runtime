var searchData=
[
  ['definitions_20of_20cryptocell_20aes_20apis',['Definitions of CryptoCell AES APIs',['../group__cc__aes__defs.html',1,'']]],
  ['d',['d',['../structmbedtls__ecdh__context.html#a22e51b2ea7d4728e48e8897535831cf4',1,'mbedtls_ecdh_context::d()'],['../structmbedtls__ecp__keypair.html#aa3d38ffe795a2953fb283644845087d6',1,'mbedtls_ecp_keypair::d()'],['../structmbedtls__rsa__context.html#ad9552371239922dd67d146b937d1aada',1,'mbedtls_rsa_context::D()']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['des_5ferror_5fidx',['DES_ERROR_IDX',['../group__cc__error.html#ga7dd4f12451a64e9f2f7e3978bcbaa428',1,'cc_error.h']]],
  ['dh_5ferror_5fidx',['DH_ERROR_IDX',['../group__cc__error.html#gaef8e04d50c02a76b2d5102303ceb1679',1,'cc_error.h']]],
  ['dhm_2eh',['dhm.h',['../dhm_8h.html',1,'']]],
  ['dmpu_5fhbk1_5fsize_5fin_5fwords',['DMPU_HBK1_SIZE_IN_WORDS',['../group__cc__dmpu.html#ga1df890fd4cd2dde8e13f4ae4df2a0bf9',1,'cc_dmpu.h']]],
  ['dmpu_5fhbk_5fsize_5fin_5fwords',['DMPU_HBK_SIZE_IN_WORDS',['../group__cc__dmpu.html#ga7f7402acae56abf0a5a5860e16dcfaf8',1,'cc_dmpu.h']]],
  ['dmpu_5fhbk_5ftype_5fhbk',['DMPU_HBK_TYPE_HBK',['../group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eea22621b9fa3b077f0d2df35235839a103',1,'cc_dmpu.h']]],
  ['dmpu_5fhbk_5ftype_5fhbk1',['DMPU_HBK_TYPE_HBK1',['../group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eeaa2d459ebfffe55c024c75c5c3b0d07cb',1,'cc_dmpu.h']]],
  ['dmpu_5fhbk_5ftype_5freserved',['DMPU_HBK_TYPE_RESERVED',['../group__cc__dmpu.html#gga8427cdb4973afbf5dc62fce810bca7eea5e4bf1fe2a73d9794192d93fba2ab77c',1,'cc_dmpu.h']]],
  ['dmpu_5fworkspace_5fminimum_5fsize',['DMPU_WORKSPACE_MINIMUM_SIZE',['../group__cc__dmpu.html#ga936e093580f1e62fe7ae1fdc6e6a569b',1,'cc_dmpu.h']]],
  ['domain',['domain',['../struct_c_c_ecpki_publ_key__t.html#a95f327d04c4e70f39c2325d4dbf83e3c',1,'CCEcpkiPublKey_t::domain()'],['../struct_c_c_ecpki_priv_key__t.html#a549b8cf21588d8077b834d64b0eabe7e',1,'CCEcpkiPrivKey_t::domain()']]],
  ['domainid',['DomainID',['../struct_c_c_ecpki_domain__t.html#a22f2eb9b2f777b4ba90fda18ffb8c266',1,'CCEcpkiDomain_t']]],
  ['dp',['DP',['../structmbedtls__rsa__context.html#aa46b066a4cf04deb4e627e69e6b036e8',1,'mbedtls_rsa_context']]],
  ['dq',['DQ',['../structmbedtls__rsa__context.html#a753b59e552469b6abb6fad9853a2042d',1,'mbedtls_rsa_context']]],
  ['dummy',['dummy',['../structmbedtls__platform__context.html#a05da2e0cbce17ebfc21036d523caff7d',1,'mbedtls_platform_context']]],
  ['dx_5fversion_5fproduct_5fbit_5fshift',['DX_VERSION_PRODUCT_BIT_SHIFT',['../group__cc__lib.html#gab34a4472043f3e154463b52c6d8e52a6',1,'cc_lib.h']]],
  ['dx_5fversion_5fproduct_5fbit_5fsize',['DX_VERSION_PRODUCT_BIT_SIZE',['../group__cc__lib.html#ga5114e1b78206a67e9a6fada4133b5fc1',1,'cc_lib.h']]]
];
