var mbedtls__cc__ecdh__edwards_8h =
[
    [ "mbedtls_ecdh_make_params_edwards", "mbedtls__cc__ecdh__edwards_8h.html#af5d6c31e3eeaeb84fdf1f58f881c6ec3", null ],
    [ "mbedtls_ecdh_read_params_edwards", "mbedtls__cc__ecdh__edwards_8h.html#a85357eb647b7c26ff690be305736dd25", null ]
];