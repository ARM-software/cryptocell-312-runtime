var cc__pal__pm_8h =
[
    [ "CC_PalPowerSaveModeInit", "group__cc__pal__pm.html#ga46e6bb20d3d3804bb2426c9dcca3b46a", null ],
    [ "CC_PalPowerSaveModeSelect", "group__cc__pal__pm.html#gade3be5438b9609c661a5ba08e8f0902c", null ],
    [ "CC_PalPowerSaveModeStatus", "group__cc__pal__pm.html#ga72e2446fc8436dce9ec2dbc52cf90a4f", null ]
];